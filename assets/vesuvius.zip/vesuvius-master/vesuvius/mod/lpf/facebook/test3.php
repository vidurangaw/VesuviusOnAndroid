<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US"
    xmlns:fb="https://www.facebook.com/2008/fbml"> 

<head prefix="og: http://ogp.me/ns# YOUR_NAMESPACE: 
    http://ogp.me/ns/apps/lpfnotify#"> 
    <meta property="fb:app_id" content="272810739444941" /> 
    <meta property="og:type" content="lpfnotify:recipe" /> 
    <meta property="og:title" content="Stuffed Cookies" /> 
    <meta property="og:image" content="http://example.com/zhen/cookie.jpg" /> 
    <meta property="og:description" content="The Turducken of Cookies" /> 
    <meta property="og:url" content="http://example.com/zhen/cookie.html"> 

</head> 

<body> 
    <div id="fb-root"></div>
    <script src="http://connect.facebook.net/en_US/all.js"></script>
    <script>
        FB.init({ 
            appId:'272810739444941', cookie:true, 
            status:true, xfbml:true, oauth:true
        });
        </script>

        <fb:add-to-timeline></fb:add-to-timeline>

        <h3>
            <font size="30" face="verdana" color="grey">
                 Stuffed Cookies
            </font> 
        </h3> 
        <p>
            <img title="Stuffed Cookies" 
                            src="http://fbwerks.com:8000/zhen/cookie.jpg" 
                            width="550"/><br />
        </p>       
    </body> 
    </html>
